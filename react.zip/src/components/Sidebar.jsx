import React, { useEffect } from "react";
import history from "../assets/Outlined.png";

const Sidebar = ({data}) => {
    useEffect(()=>{
        console.log(data);
    },[])
  return (
    <div className="sidebar_container">
      <div className="new_chat">+ New Chat</div>
      <h3 className="activity">Activity</h3>
      {data?.map((datum) => {
        return (
          <div className="history">
            <img src={history} alt="" /> {datum.title}
          </div>
        );
      })}
    </div>
  );
};

export default Sidebar;
