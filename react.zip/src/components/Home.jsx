import React, { useEffect, useState } from "react";
import Navbar from "./Navbar";
import Sidebar from "./Sidebar";
import Chat from "./Chat";
import { w3cwebsocket as W3CWebSocket } from "websocket";

export const Home = () => {
    const [conversation, setConversation] = useState([]);
  const [webSocket, setWebSocket] = useState(null);
  const [loading, setLoading] = useState(false); 
  const [allData, setAllData] = useState([{
    title: "Part Number",
    question: ["test"],
    answer: ["test"]
  }]);
  const [currentData, setCurrentData] = useState({});
  useEffect(() => {
    if (webSocket) {
      return;
    }
    const socket = new W3CWebSocket("ws://34.134.236.42:8766/");
    socket.onopen = function (event) {
      console.log('Connected to server. Start chatting! Type "quit" to exit.');
      setWebSocket(socket);
    };

    socket.onmessage = function (event) {
      const message = event.data;
      handleUserInput(message);
    };

    socket.onerror = function (error) {
      console.error("WebSocket error:", error);
    };

    socket.onclose = function (event) {
      console.log("WebSocket connection closed");
    };

    return () => {
      if (webSocket) {
        socket.close();
        setWebSocket();
      }
    };
  }, [webSocket]);
  
  useEffect(()=>{
    console.log("con ",conversation);
  },[conversation])
  const handleUserInput = (data) => {
    setConversation((prev) => [
      ...prev,
      {
        type: "bot",
        text: data,
      },
    ]);
    setLoading(false);
  };
  const handleSendMessage = (message) => {
      if (
          webSocket &&
          webSocket.readyState === WebSocket.OPEN &&
          message.trim() !== ""
          ) {
              if(conversation.length === 0 ){
            console.log(message, conversation);
            webSocket.send(new Date().valueOf());
        }
      webSocket.send(message);
      if (message.toLowerCase() === "quit") {
        webSocket.close();
      } else {
        setConversation((prev) => [
          ...prev,
          {
            type: "user",
            text: message,
          },
        ]);
      }
      setLoading(true);
    }
  };
  return (
    <div className="home_container">
      <Navbar />
      <div className="home_body">
        <Sidebar data={allData} />
        <div className="chat_container">
          <Chat submitData={handleSendMessage} loading={loading} data={currentData} listData={conversation} />
        </div>
      </div>
    </div>
  );
};
